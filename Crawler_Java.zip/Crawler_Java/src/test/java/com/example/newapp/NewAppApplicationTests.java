package com.example.newapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
