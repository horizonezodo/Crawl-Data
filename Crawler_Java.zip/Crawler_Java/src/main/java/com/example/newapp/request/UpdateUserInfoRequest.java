package com.example.newapp.request;

import lombok.Data;

@Data
public class UpdateUserInfoRequest {
    String new_pass;
}
