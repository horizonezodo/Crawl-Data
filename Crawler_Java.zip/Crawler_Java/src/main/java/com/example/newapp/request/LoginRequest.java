package com.example.newapp.request;


import lombok.Data;

@Data
public class LoginRequest {
    String email;
    String password;
}
