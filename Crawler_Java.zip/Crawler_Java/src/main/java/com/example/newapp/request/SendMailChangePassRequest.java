package com.example.newapp.request;

import lombok.Data;

@Data
public class SendMailChangePassRequest {
    String email;
}
