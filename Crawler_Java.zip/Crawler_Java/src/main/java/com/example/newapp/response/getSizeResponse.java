package com.example.newapp.response;

import lombok.Data;

@Data
public class getSizeResponse {
    Long size;
}
