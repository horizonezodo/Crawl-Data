package com.example.newapp.request;

import lombok.Data;

@Data
public class checkTokenRequest {
    String token;
}
