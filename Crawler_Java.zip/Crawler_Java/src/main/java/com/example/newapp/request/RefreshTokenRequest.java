package com.example.newapp.request;

import lombok.Data;

@Data
public class RefreshTokenRequest {
    private String refreshToken;
}
